﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_Project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
