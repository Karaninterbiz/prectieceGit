﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    interface IService
    {
        void ServiceVehicle();
    }

    abstract class VehicleService:IService
    {
        public void PerformService()
        {
            Console.WriteLine("Performing common service...");
        }
       public  void ServiceVehicle()
        {

        }
        public abstract void SpecificService();
    }
    class Vehicle: VehicleService
    {
        private string name;
        private string company;
        private int model;

        public string setName
        {
            get { return name; }
            set { name = value; }
        }
        public string setConpamy
        {
            get { return company; }
            set { company = value; }
        }
        public int setModel
        {
            get { return model; }
            set { model = value; }
        }
        public virtual void StartEngine()
        {
            Console.WriteLine("Starting the vehicle engine...");
        }
        public override void SpecificService()
        {
            Console.WriteLine("service has performed");
        }
    }
    class Car : Vehicle
    {
        public override void StartEngine()
        {
            Console.WriteLine("Starting car engine...");
        }
    }
    class Truck : Vehicle
    {
        public override void StartEngine()
        {
            Console.WriteLine("Starting truck engine...");
        }
    }
    class Bike : Vehicle
    {
        public override void StartEngine()
        {
            Console.WriteLine("Starting bike engine...");
        }
    }

    // Interface for service
   
    class BasicVehicle
    {
        public void StartEngine()
        {
            Console.WriteLine("Basic vehicle engine started.");
        }
    }
    class AdvancedVehicle : BasicVehicle
    {
        // Method hiding: Hide the StartEngine method
        new public void StartEngine()
        {
            Console.WriteLine("Advanced vehicle engine started with advanced features.");
        }
    }
    internal class Program
    {
        static string name, company;
        static int model;
        static void Main(string[] args)
        {
            Console.WriteLine();
            while (true)
            {
                Console.Clear();
                Console.WriteLine("vehicle management system");
                try
                {
                    Console.Write("Enter your vehicle type[(Car)\t(Truck)\t(Bike)]:=");
                    String type = Console.ReadLine();
                    string vehicle = type.ToLower();
                    if (vehicle == "car" || vehicle == "truck" || vehicle == "bike")
                    {
                        switch (vehicle)
                        {
                            case "car":
                                Console.Clear();
                                Car car = new Car();
                                Console.Write("Enter Your Car Name:");
                                name = Console.ReadLine();

                                Console.Write("Enter Your Car Model:");
                                model = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Enter Your Car company:");
                                company = Console.ReadLine();
                                car.setName = name;
                                car.setModel = model;
                                car.setConpamy = company;
                                // car.ServiceVehicle();
                                car.StartEngine();
                                car.PerformService();
                                Console.ReadKey();
                                break;

                            case "truck":
                                Console.Clear();
                                Truck truck = new Truck();
                                Console.WriteLine("Enter Your Truck Name:");
                                name = Console.ReadLine();

                                Console.WriteLine("Enter Your Truck Model:");
                                model = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Enter Your Truck company:");
                                company = Console.ReadLine();
                                truck.setName = name;
                                truck.setModel = model;
                                truck.setConpamy = company;
                                // truck.ServiceVehicle();
                                truck.PerformService();
                                truck.StartEngine();
                                break;

                            case "bike":
                                Console.Clear();
                                Bike bike = new Bike();
                                //name
                                Console.WriteLine("Enter Your bike Name:");
                                name = Console.ReadLine();

                                Console.WriteLine("Enter Your bike Model:");
                                model = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Enter Your bike company:");
                                company = Console.ReadLine();
                                bike.setName = name;
                                bike.setModel = model;
                                bike.setConpamy = company;
                                //  bike.ServiceVehicle();
                                bike.PerformService();
                                bike.StartEngine();
                                break;

                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid:[vehicle category:] press key to locate main menu");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }
                catch(Exception exception)
                {
                    Console.WriteLine("Please enter the model ");
                    Console.ReadKey();
                }
            }
            
        }
    }
}

