﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
namespace Part_6
{
    internal class Program
    {
        private static readonly string filePath = @"C:\example.txt";

        //    // Write to file operation
        static void WriteToFile()
        {
            Console.WriteLine("Writing into file");
            Console.WriteLine("==================");
            try
            {
                Console.WriteLine("Enter the Content :");
                string content = Console.ReadLine();
                File.AppendAllText(filePath, content);
                Console.WriteLine($"Your Content [{content}] added into file at{DateTime.Now}");
                Thread.Sleep(1000);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error writing to file: " + ex.Message);
            }
            Console.WriteLine();
        }
        // Read from file operation
        static void ReadFromFile()
        {
            Console.WriteLine("Reading from file");
            Console.WriteLine("==================");
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    Console.WriteLine(line);
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading file: " + ex.Message);
            }
        }

        static async void Main(string[] args)
        {
            // Start reading and writing operations asynchronously
            Console.WriteLine("main start");
            var writeTask = Task.Run(WriteToFile);
            var readTask = Task.Run(ReadFromFile);
            // Wait for both tasks to complete
            await Task.WhenAll(writeTask, readTask);
            Console.WriteLine("main end");
        }
    }
}
