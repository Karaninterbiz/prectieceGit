﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3.Math_Helper
{
    partial class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public void DisplayFullName()
        {
            Console.WriteLine($"Full Name: {FirstName} {LastName}");
        }
    }
    internal partial class Person
    {
        public int Age { get; set; }

        public void DisplayDetails()
        {
            Console.WriteLine($"Name: {FirstName} {LastName}, Age: {Age}");
        }
    }
}
