﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3.EmployeeHierarchy
{
    // Immutable record for Employee details
    public record EmployeeDetails(string Name, string Position, int EmployeeId);
    public abstract class Employee
    {
        public EmployeeDetails Details;
        protected Employee(EmployeeDetails details)
        {
            Details = details;
        }
        public abstract double CalculateSalary();
    }
}
