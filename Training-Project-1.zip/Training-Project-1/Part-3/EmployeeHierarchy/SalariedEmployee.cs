﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3.EmployeeHierarchy
{
    internal class SalariedEmployee: Employee
    {

        public double MonthlySalary;
        public override double CalculateSalary()
        {
            return MonthlySalary+30000;
        }
        

        public SalariedEmployee(EmployeeDetails details, double monthlySalary )  : base(details)
     
        {
            MonthlySalary = monthlySalary;
        }


    }
}
