﻿using System.Runtime.CompilerServices;
using System.Threading.Channels;
using Part_3.EmployeeHierarchy;
using Part_3.StudentRecords;
using Part_3.Math_Helper;
namespace Part_3
{
   
        internal class Program
        {
            static int studentId;
            static string studentName;
            static int choice;
            static void Main(string[] args)

            {
                Student students = new Student();
                while (true)
                {
                    try
                    {
                        Console.Clear();
                        Console.WriteLine("Welcome to Student Management System");
                        Console.WriteLine("Add Student Record :[1]");
                        Console.WriteLine("View Studend Record :[2] ");
                        Console.WriteLine("Add Employee Record :[3]");
                        Console.WriteLine("Sealed & MathHelper :[4]");
                        Console.Write("Enter Your Choice: =");
                        choice = Convert.ToInt32(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                Console.Write("Add your Id:=");
                                studentId = Convert.ToInt32(Console.ReadLine());
                                students.ID = studentId;
                                Console.Write("Add your Name:=");
                                studentName = Console.ReadLine();
                                if (string.IsNullOrEmpty(studentName))
                                {
                                    throw new ArgumentNullException();
                                }
                                else students.Name = studentName;
                                Console.WriteLine("Select Course Category:");
                                foreach (var course in Enum.GetValues(typeof(Student.CourseCategory)))
                                {
                                    Console.WriteLine($"{(int)course}. {course}");
                                }
                                Console.Write("Enter Course Category Number: ");
                                int categoryChoice = Convert.ToInt32(Console.ReadLine());

                                if (Enum.IsDefined(typeof(Student.CourseCategory), categoryChoice))
                                {
                                    var selectedCategory = (Student.CourseCategory)categoryChoice;
                                    students.SetCourseCategories = selectedCategory;
                                    Console.WriteLine($"{studentName}: you added your details successfully....");
                                    Console.ReadKey();
                                }
                                break;
                            case 2:
                                Console.WriteLine($"ID: {students.ID}, Name: {students.Name}, Course: {students.SetCourseCategories}");
                                Console.ReadKey();
                                break;

                             case 3:
                                    Console.Write("Enter your Name:");
                                    string employeeName = Console.ReadLine();
                                    if (string.IsNullOrEmpty(employeeName))
                                    {
                                        throw new ArgumentNullException();
                                    }
                                     
                                    Console.Write($"Hi [ {employeeName}] Enter your Position:");
                                    string employeePosition=Console.ReadLine();
                                    Console.Write("Your Employee Id: ");
                                    int employeeId=Convert.ToInt32(Console.ReadLine());
                                     Console.Write("Enter your salary:");
                                     double employeeSalary = Convert.ToDouble(Console.ReadLine());
                                    //passing record obeject
                                      SalariedEmployee employee = new SalariedEmployee(new EmployeeDetails(employeeName, employeePosition, employeeId), 5000);
                                      Console.WriteLine(employee.Details);
                                      Console.WriteLine("Total yearly salary included Bonus "+employee.CalculateSalary());
                                      Console.ReadKey();
                            break;
                             case 4:
                                //partial class
                                Person person = new Person()
                                {
                                    FirstName = "Jane",
                                    LastName = "Smith",
                                    Age = 25
                                };
                                    // Display person details
                                    person.DisplayFullName();
                                    person.DisplayDetails();
                                      // Use MathHelper for calculations
                                     MathHelper helper=new MathHelper();
                                     Console.WriteLine(helper.Add(10,20));
                                     Console.WriteLine(helper.Subtract(10, 20));
                                     Console.ReadKey();
                            break;
                            default:
                                Console.WriteLine("Invalid Choice.......");
                                Console.ReadKey();
                            break;
                        }
                    }
                    catch (ArgumentNullException argumentNullException)
                    {
                        Console.WriteLine(argumentNullException.Message);
                        Console.ReadKey();
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(" Must be Interger Number.......");
                        Console.ReadKey();

                    }
                }
            }

        }
}

