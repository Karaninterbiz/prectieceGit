﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3.StudentRecords
{
    internal class Student
    {
        public struct StudentRecord
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public CourseCategory Category { get; set; }


            public StudentRecord(int id, string name, CourseCategory category)
            {
                ID = id;
                Name = name;
                Category = category;

            }

            public void DisplayRecord()
            {
                Console.WriteLine($"ID: {ID}, Name: {Name}, Course: {Category}");
            }
        }

        // Enum for Course Categories
        public enum CourseCategory
        {
            None,
            Science,
            Arts,
            Commerce,
            Technology
        }

        // Private fields
        private int _id;
        private string _name;
        private CourseCategory _courseCategory;


        // Public properties of Id
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public CourseCategory SetCourseCategories
        {
            get { return _courseCategory; }
            set { _courseCategory = value; }
        }


        // Protected Method
        protected void DisplayProtectedInfo()
        {
            Console.WriteLine("This is protected information.");
        }

        // Public Method to display student details
        public void DisplayDetails()
        {
            Console.WriteLine($"Student Details: ID = {ID}, Name = {Name}, Course = {SetCourseCategories}");
        }
    }
}
