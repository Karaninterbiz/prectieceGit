﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_5
{
    internal class ReflectionDemoClass
    {
        public string Greet(string name)
        {
            return $"Hello, {name}!";
        }
    }
}
