﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Reflection;
namespace Part_5
{
    // Extension method for string reversal
    

    // Custom exception
    class CustomException :Exception
    {
        public CustomException(string message) : base(message)
        {

        }
    }
    // Class for reflection demo
   
    internal class Program
    {

        public static void Main(string[] args)
        {
            // 1. Reflection: Dynamically load class and invoke method
            Console.WriteLine("Reflection Demo:");

            Type type = typeof(ReflectionDemoClass);
            Object activator = Activator.CreateInstance(type);
            MethodInfo methodInfo = type.GetMethod("Greet", BindingFlags.Public | BindingFlags.Instance);
            methodInfo.Invoke(activator, new Object[] { "sourabh" });


           

            // 3. Extension Method: Reverse a string
            Console.WriteLine("\nExtension Method Demo:");
            Console.WriteLine("");
            while (true)
            {
                Console.Clear();
                Console.WriteLine("String Reverse :[1]");
                Console.WriteLine("perfor addition and multiplication :[2]");
                Console.WriteLine("Custom Exception :[3]");
                try
                {
                    Console.Write("Set Choise=");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    if (choice >= 1 && choice <= 3)
                    {
                        switch (choice)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("Enter your name:");
                                string name = Console.ReadLine();
                                Console.WriteLine("==============");
                                Console.WriteLine($"Your name {name} reverse to:" + name.Reverse());
                                Console.ReadKey();
                                break;

                            case 2:
                                Console.Clear();
                                Console.Write("Enter 1st Number:");
                                double firstNumber = Convert.ToDouble(Console.ReadLine());
                                Console.Write("Enter 2nd Number:");
                                double secondNumber = Convert.ToDouble(Console.ReadLine());
                                var (sum, product) = Calculate(firstNumber, secondNumber);
                                Console.WriteLine($"Sum: {sum}, Product: {product}");
                                Console.ReadKey();
                                break;

                            case 3:
                                try
                                {
                                    Console.Clear();
                                    Console.Write("Enter your Age:");
                                    int inputAge = Convert.ToInt32(Console.ReadLine());
                                    if (inputAge < 0)
                                    {
                                        throw new CustomException("Age can not be negative");
                                    }
                                }
                                catch (CustomException e)
                                {
                                    Console.WriteLine(e.Message);
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                }
                                Console.ReadKey();
                                break;
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid Choice");
                        Console.ReadKey();
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine("Allows only Integer Choice");
                    Console.ReadKey();
                }
            }

           
        }
        static (double , double  ) Calculate(double a, double b)
        {
            return( a + b,a*b);
           
        }
    }
}
