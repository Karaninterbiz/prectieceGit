﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_4.Non_Generic
{
    using Part_4;
    internal class NonGenericProduct
    {
        public static void ProductNonGeneric()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Welcome to Non-Generic Items Collection");
                Console.WriteLine("=================================");
                Console.WriteLine("Product Entry:[1]");
                Console.WriteLine("Product Entry with Id[2]");
                Console.WriteLine("Show Inventory :[3]");
                Console.WriteLine("Go back to Menu [4]");
                Console.WriteLine();
                try
                {
                    Console.Write("Enter Choice :");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            ForNonGen.ProductWithArrayList();
                            break;

                        case 2:
                            ForNonGen.ProductWithHashtable();
                            break;

                        case 3:
                            ForNonGen.ShowProductWithArrayList();
                            Console.WriteLine();
                            ForNonGen.ShowProductWithHashtable();
                            break;

                        case 4:
                           
                            Console.Clear();
                           
                            return;
                            
                            break;

                        default:
                            Console.WriteLine("Invalid choice");
                            Console.ReadKey();
                            break;
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine("Inter Integer choice only........");
                    Console.ReadKey();
                }
            }
        }
    }
}
