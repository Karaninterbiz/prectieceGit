﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_4.Non_Generic
{
    internal class ForNonGen
    {
        static ArrayList productArrayList = new ArrayList();
        static Hashtable productHashtable = new Hashtable();
        public static void ProductWithArrayList()
        {
            try
            {
                Console.Write("Enter product Quantity :");
                int quantity = Convert.ToInt32(Console.ReadLine());
                for (int i = 1; i <= quantity; i++)
                {
                    Console.Write($"Enter {i}st product  :");
                    string product = Console.ReadLine();
                    productArrayList.Add(product);
                }
                Console.WriteLine("Successfully added...");
                Console.ReadKey();
            }
            catch(Exception e)
            {
                Console.WriteLine("Please Enter Integer Quantity:");
                Console.ReadKey();
            }
        }
        public static void ShowProductWithArrayList()
        {
            foreach (var v in productArrayList)
            {
                Console.WriteLine("product= " + v);
            }

        }
        public static void ProductWithHashtable()
        {
            Console.Write("Enter product Quantity :");
            int quantity = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= quantity; i++)
            {
                Console.Write($"Enter {i}st product Id: ");
                string productId = Console.ReadLine();
                Console.Write($"Enter {i}st product Name: ");
                string productName = Console.ReadLine();
                productHashtable.Add(productId, productName);
            }
            Console.WriteLine("Successfully added...");
            Console.ReadLine();
        }
        public static void ShowProductWithHashtable()
        {
            foreach (DictionaryEntry entry in productHashtable)
            {
                Console.WriteLine($"ID: {entry.Key}, Product: {entry.Value}");
            }
            Console.ReadLine();
        }
    }
}

