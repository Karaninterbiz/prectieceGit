﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_4
{
    internal class Class1
    {
       public int x;
       public string name;
       public double salary;
        public void id(int id,int i)
        {
            Console.WriteLine(id+""+i);
        }
        public void Name()
        {
            Console.WriteLine("sourabh");
        }
    }
}
