﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Part_4.Non_Generic;
using Part_4.Generic;
using System.CodeDom;
namespace Part_4
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            //Type type = typeof(Class1);
            //Object ob=Activator.CreateInstance(type);
            //MemberInfo[] minfo=type.GetMembers();
            //Console.WriteLine("all membres");
            //foreach(MemberInfo m in minfo)
            //{
            //    Console.WriteLine(m);
            //}
            //Console.WriteLine();
            //Console.WriteLine("all fields");

            //FieldInfo[]finfo=type.GetFields();
            //foreach(FieldInfo f in finfo)
            //{
            //    Console.WriteLine(f);   
            //}
            //Console.WriteLine();
            //Console.WriteLine("all methods");

            //MethodInfo[] mrthodinfo=type.GetMethods();  
            //foreach(MethodInfo m in mrthodinfo)
            //{
            //    Console.WriteLine(m);
            //}
            //Console.WriteLine("specific field");

            //FieldInfo f1 = type.GetField("x",BindingFlags.Public | BindingFlags.Instance);
            //Console.WriteLine(f1.Name);

            //f1.SetValue(ob, 1625);

            //Console.WriteLine(f1.GetValue(ob));

            //Console.WriteLine("specific method");
            //MethodInfo m1 = type.GetMethod("id",BindingFlags.Public | BindingFlags.Instance);
            //Console.WriteLine(m1.Name);
            //m1.Invoke(ob,new object[] { 1,2});

            //Console.WriteLine();
            //MethodInfo m2 = type.GetMethod("Name", BindingFlags.Public | BindingFlags.Instance);
            //Console.WriteLine(m2.Name);
            //m2.Invoke(ob, null);

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Non Generic Products :[1]");
                Console.WriteLine("Generic Products :[2]");
                Console.WriteLine("Show Inventory :[3]");
                try
                {
                    Console.Write("Enter Choice=");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    if (choice >= 1 && choice <= 3)
                    {
                        while (true)
                        {
                            switch (choice)
                            {
                                case 1:
                                    NonGenericProduct.ProductNonGeneric();
                                    break;

                                case 2:
                                    GenericProduct.ProductGeneric();
                                    break;
                                case 3:

                                    Part_4.Non_Generic.ForNonGen.ShowProductWithArrayList();
                                    Part_4.Non_Generic.ForNonGen.ShowProductWithHashtable();
                                    Part_4.Generic.GenList.ShowProductWithList();
                                    Part_4.Generic.productWithDictionary.ShowDictionaryItem();
                                    Part_4.Generic.productWithSortedList.ShowSortedListItems();
                                    return;
                                 break;

                                
                                default:
                                    Program.Main(args);
                                    Console.WriteLine("Invalid choice");
                                    Console.ReadLine();
                                    return;
                                    break;
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Choice....");
                        Console.ReadKey();  
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Please Enter Integer Choice");
                    Console.ReadKey();
                }
            }
        }
    }
    public class Inventory
    {
        public static void ProductInventory()
        {

        }
    }
}
