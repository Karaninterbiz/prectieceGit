﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_4.Generic
{
    internal class productWithSortedList
    {
        static SortedList<string, string> productSortedList = new SortedList<string, string>();
        public static void SortedListItem()
        {
            Console.Write("Enter product Quantity :");
            int quantity = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= quantity; i++)
            {
                Console.Write($"Enter {i}st product Id: ");
                string productId = Console.ReadLine();
                Console.Write($"Enter {i}st product Name: ");
                string productName = Console.ReadLine();
                productSortedList.Add(productId, productName);
            }
            Console.WriteLine("Successfully added...");
        }
        public static void ShowSortedListItems()
        {
            foreach (var items in productSortedList)
            {
                Console.WriteLine($"ID: {items.Key}, Product: {items.Value}");
            }

        }
    }
}

