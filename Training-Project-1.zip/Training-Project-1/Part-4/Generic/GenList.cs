﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_4.Generic
{
    internal class GenList
    {
        static List<string> productList = new List<string>();
        public static void ProductWithList()
        {
            Console.Write("Enter product Quantity :");
            int quantity = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= quantity; i++)
            {
                Console.WriteLine($"Enter {i}st product :");
                string product = Console.ReadLine();
                productList.Add(product);
            }
            Console.WriteLine("Successfully added...");
        }

        public static void ShowProductWithList()
        {
            foreach (var v in productList)
            {
                Console.WriteLine("product " + v);
            }

        }
    }
}
