﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Part_4;

namespace Part_4.Generic
{
    
    internal class GenericProduct
    {
        static int choice;
        public static void ProductGeneric()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Welcome to Generic Items Collection");
                Console.WriteLine("=================================");
                Console.WriteLine("Product Entry :[1]");
                Console.WriteLine("Product Entry with Id :[2]");
                Console.WriteLine("Product Entry with Order :[3]");
                Console.WriteLine("Show Inventory :[4]");
                Console.WriteLine("Go back to Menu [5]");
                try
                {
                    Console.WriteLine("Enter Choice");
                     choice = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine("Allow Only Integer Choice");
                }
                switch (choice)
                    {
                        case 1:
                            GenList.ProductWithList();
                            break;

                        case 2:
                            productWithDictionary.DictionaryItem();
                            break;

                        case 3:
                            productWithSortedList.SortedListItem();
                            break;

                        case 4:
                            GenList.ShowProductWithList();
                            productWithDictionary.ShowDictionaryItem();
                            productWithSortedList.ShowSortedListItems();
                            break;

                        case 5:
                             Console.Clear();
                        return;
                        break;
                        default:
                            Console.WriteLine("Invalid choice");
                            Console.ReadKey();
                            break;
                    }
                
                
            }
        }
    }
}
