﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.LibraryManagementModule
{
    internal class LibraryManagementModule
    {
        public static void Library()
        {
            Console.Clear();
            Library libraryManager = new Library();
            libraryManager.AddBook(1, "Making India Awesome", "Chetan Bhagat");
            libraryManager.AddBook(2, "Bharat Bharati ", "Maithili Saran Gupt");
            libraryManager.AddBook(3, "Gitanjali", "Rabindranath Tagore");
            Console.WriteLine();
            // Display inventory
            libraryManager.DisplayInventory();

            Console.WriteLine();
            // Issue books
            Console.WriteLine(libraryManager.IssueBook(1, "Ram")); ;
            Console.WriteLine(libraryManager.IssueBook(2));

            Console.WriteLine();
            // Display inventory after issuance
            libraryManager.DisplayInventory();

            Console.WriteLine();
            // Return a book
            Console.WriteLine(libraryManager.ReturnBook(1));
            Console.WriteLine(libraryManager.ReturnBook(3));

            Console.WriteLine();
            // Display inventory
            libraryManager.DisplayInventory();

            Console.WriteLine();
            // Display total books issued
            Console.WriteLine($"total book issued {libraryManager.TotalBooksIssued}");




        }
    }
}
