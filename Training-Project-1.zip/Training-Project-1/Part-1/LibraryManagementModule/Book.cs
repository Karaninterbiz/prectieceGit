﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.LibraryManagementModule
{
    internal class Book
    {
        public int BookId;
        public string Title;
        public string Author;
        public bool IsIssued;

        public Book(int bookId, string title, string author)
        {
            this.BookId = bookId;
            this.Title = title;
            this.Author = author;
            this.IsIssued = false;
        }
    }
}
