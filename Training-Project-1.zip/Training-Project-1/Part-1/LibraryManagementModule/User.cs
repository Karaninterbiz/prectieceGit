﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.LibraryManagementModule
{
    internal class User
    {
        public int userId;
        public string name;

        public User(int userId, string name)
        {
            this.userId = userId;
            this.name = name;
        }
    }
}
