﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.LibraryManagementModule
{
    internal class Library
    {
        List<Book> inventory = new List<Book>();
        public int TotalBooksIssued = 0;

        // Method to add books to inventory
        public void AddBook(int bookId, string title, string author)
        {
            inventory.Add(new Book(bookId, title, author));
        }

        // Method to issue a book
        public string IssueBook(int BookId, string IssuedTo = "Anonymous")
        {
            var book = inventory.Find(b => b.BookId == BookId);
            if (book != null && !book.IsIssued)
            {
                book.IsIssued = true;
                TotalBooksIssued++;
                return $"Book '{book.Title}' issued to {IssuedTo}.";
            }
            else if (book == null)
            {
                return "Book not found in inventory.";
            }
            else
            {
                return "Book is already issued.";
            }
        }

        // Method to return a book
        public string ReturnBook(int bookId)
        {
            var book = inventory.Find(b => b.BookId == bookId);
            if (book != null && book.IsIssued)
            {
                book.IsIssued = false;
                return $"Book '{book.Title}' returned successfully.";
            }
            else if (book == null)
            {
                return "Book not found in inventory.";
            }
            else
            {
                return "Book was not issued.";
            }
        }

        // Method to display inventory
        public void DisplayInventory()
        {
            Console.WriteLine("Library Inventory:");
            foreach (var book in inventory)
            {
                string status = book.IsIssued ? "Issued" : "Available";
                Console.WriteLine($"ID: {book.BookId}, Title: {book.Title},Author: {book.Author},Status: {status}");
            }
        }
    }
}
