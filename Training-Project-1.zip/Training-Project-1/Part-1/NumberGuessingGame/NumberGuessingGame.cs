﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.NumberGuessingGame
{
    internal class NumberGuessingGame
    {
        public static void GussingNumber()
        {
            Console.Clear();
            Random random = new Random();
            int num = random.Next(1,11);
            double guess = 0, count = 1;
            Console.WriteLine("welcome to number guessing game  ");
            Console.WriteLine("guess the number between 1-10");
           
            while (guess != num)
            {
                try
                {

                   
                    Console.Write("Enter your guess: ");
                    guess = Convert.ToInt32(Console.ReadLine());

                    if (guess == num)
                    {
                        Console.WriteLine($"Congratulations! You guessed the correct number ({guess}) in {count} attempts. "+num);
                        count++;

                    }
                    else if (guess < num)
                    {
                        Console.WriteLine($"Too low! [{count}:attempt]");
                        count++;

                    }
                    else
                    {
                        Console.WriteLine($"Too high! [{count}:attempt]");
                        count++;
                    }
                }
                catch(FormatException e)
                {
                   
                    Console.WriteLine(e.Message+" Please inter Interege Value");
                  
                   
                }
            }
        }
    }
}
