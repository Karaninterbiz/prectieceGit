﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Perform the Task");
            Console.WriteLine("=====================");
            Console.WriteLine("Calculator :1");
            Console.WriteLine("Number Guessing Game :2");
            Console.WriteLine("Library Management Module :3\n");

            Console.Write("Enter your choice :");
            
            
            string userInput = Console.ReadLine();

            if (string.IsNullOrEmpty(userInput))
            {
                Console.WriteLine("Enter the valid choice");
                Console.ReadKey();
                Program.Main(args);

            }
            else if (int.TryParse(userInput, out int i) && i > 3 || i < 1)
            {
                Console.WriteLine("Enter the valid choice");
                Console.ReadKey();
                Program.Main(args);
            }
            else if (int.TryParse(userInput, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        // Clear the console
                        Console.Clear();
                        Part_1.Calculator.Calculator.Calculation();
                        //namespace and class and static method
                        break;

                    case 2:
                        Part_1.NumberGuessingGame.NumberGuessingGame.GussingNumber();

                        break;

                    case 3:
                        Part_1.LibraryManagementModule.LibraryManagementModule.Library();
                        break;
                }

            }
            else
            {
                Console.WriteLine("please Inter Integer Value:");
               
            }

        }
    }
}
