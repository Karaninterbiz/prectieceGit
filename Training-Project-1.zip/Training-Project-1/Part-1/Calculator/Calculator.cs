﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1.Calculator
{
    using Part_1;
    internal class Calculator
    {

        public static void Calculation()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Calculator Operations:");
                Console.WriteLine("=======================");
                Console.WriteLine("Addition:1");
                Console.WriteLine("Subtraction:2");
                Console.WriteLine("Multiplication:3");
                Console.WriteLine("Division:4");
           
                try { 
                Console.Write("Enter the choice:=");
                int choice = Convert.ToInt32(Console.ReadLine());
               
                if (choice >= 1 && choice <= 4)

                {
                    Console.Write("Enter first number:=");
                    dynamic firstnumber = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter second number:=");
                    dynamic secondnumber = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:

                            Console.WriteLine($"Addition={firstnumber + secondnumber}");
                            Console.ReadLine();
                            Console.Clear();

                            break;

                        case 2:
                            Console.WriteLine($"Subtraction={firstnumber - secondnumber}");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        case 3:
                            Console.WriteLine($"Multiplication={firstnumber * secondnumber}");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        case 4:
                                
                                if(firstnumber==0 || secondnumber==0)
                                {

                                    throw new DivideByZeroException("Divide by Zero Exception");
                                 
                                }
                                else
                                {
                                    Console.WriteLine($"Division={firstnumber / secondnumber}");
                                    Console.ReadLine();
                                    Console.Clear();
                                }
                          
                            break;
                        
                        default:
                            Console.WriteLine("wrong choice");
                            break;
                    }


                }
                else
                {
                    Console.WriteLine("Enter the correct choice");
                    Console.ReadKey();

                }
              }
              catch(FormatException)
              {
                    Console.WriteLine("Enter the Interger Value");
                    Console.ReadKey();
              }
               catch(Exception divide)
                {
                    Console.WriteLine(divide.Message);
                    Console.ReadKey();
                }
            }
        }
    }
}
