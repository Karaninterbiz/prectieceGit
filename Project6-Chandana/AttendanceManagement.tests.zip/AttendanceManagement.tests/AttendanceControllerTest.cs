﻿using AttendanceManagement.Controllers;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using AttendanceManagement.Controllers;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AttendenceManagementSystem.Test.ControllersTest
{
    public class AttendanceControllersTest
    {
        [Fact]
        public async Task GetMyAttendance_ReturnsOkResult_WithAttendanceRecords()
        {
            // Arrange
            var mockAttendanceServices = new Mock<IAttendanceServices>();
            var attendanceRecords = new List<Attendance>
    {
        new Attendance { AttendanceId = 1, UserId = 1, AttendanceDate = DateTime.UtcNow, Status = "Present" }
    };
            mockAttendanceServices.Setup(s => s.GetAttendanceByUserIdAsync(1)).ReturnsAsync(attendanceRecords);

            var controller = new AttendanceController(mockAttendanceServices.Object);
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, "1") }))
                }
            };

            // Act
            var result = await controller.GetMyAttendance();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(attendanceRecords, okResult.Value);
        }


    }
}
