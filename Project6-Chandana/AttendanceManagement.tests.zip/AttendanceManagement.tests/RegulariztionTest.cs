﻿using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using AttendanceManagement.Controllers;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using AttendanceManagement.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using AttendanceManagement.Services.Implementations;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Xunit;
using AttendanceManagement.tests;

namespace AttendenceManagementSystem.Test.ControllersTest
{
    public class RegularizationRequestTest
    {
        private readonly Mock<IRegularizationRequestServices> _mockServices;
        private readonly RegularizationController _controller;

        public RegularizationRequestTest()
        {
            _mockServices = new Mock<IRegularizationRequestServices>();
            _controller = new RegularizationRequestController(_mockServices.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, "1") }))
                }
            };
        }

        //  UNIT TESTS FOR CreateRegularizationRequest 


        [Fact]
        public async Task CreateRegularizationRequest_Returns500_WhenExceptionIsThrown()
        {
            // Arrange
            var requestDTO = new RegularizationCommandModel { AttendanceDate = DateTime.UtcNow, Reason = "Sick Leave" };
            _mockServices.Setup(s => s.CreateRegularizationRequestAsync(1, requestDTO.AttendanceDate, requestDTO.Reason))
                         .ThrowsAsync(new Exception("Unexpected error."));

            // Act
            var result = await _controller.CreateRegularizationRequest(requestDTO);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusCodeResult.StatusCode);
        }



        // UNIT TESTS FOR ApproveOrDenyRequest 
        [Fact]
        public async Task ApproveOrDenyRequest_ReturnsOkResult_WhenRequestIsProcessedSuccessfully()
        {
            // Arrange
            int requestId = 1;
            bool isApproved = true;
            _mockServices.Setup(s => s.ApproveOrDenyRequestAsync(requestId, isApproved, 1))
                         .ReturnsAsync(true);

            // Act
            var result = await _controller.ApproveOrDenyRequest(requestId, isApproved);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Request processed successfully.", okResult.Value);
        }

        [Fact]
        public async Task ApproveOrDenyRequest_ReturnsNotFound_WhenRequestIsNotFound()
        {
            // Arrange
            int requestId = 1;
            bool isApproved = false;
            _mockServices.Setup(s => s.ApproveOrDenyRequestAsync(requestId, isApproved, 1))
                         .ReturnsAsync(false);

            // Act
            var result = await _controller.ApproveOrDenyRequest(requestId, isApproved);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Request not found.", notFoundResult.Value);
        }





        //  UNIT TESTS FOR GetRegularizationRequestsByUser
        [Fact]
        public async Task GetRegularizationRequestsByUser_ReturnsOkResult_WhenRequestsExist()
        {
            // Arrange
            int userId = 1;
            var requests = new List<RegularizationRequest>
            {
                new RegularizationRequest { RequestId = 1, Status = "Pending" }
            };
            _mockServices.Setup(s => s.GetRegularizationRequestsByUserIdAsync(userId))
                         .ReturnsAsync(requests);

            // Act
            var result = await _controller.GetRegularizationRequestsByUser(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(requests, okResult.Value);
        }

        [Fact]
        public async Task GetRegularizationRequestsByUser_ReturnsUnauthorized_WhenUserMismatch()
        {
            // Arrange
            int userId = 2;

            // Act
            var result = await _controller.GetRegularizationRequestsByUser(userId);

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedResult>(result);
        }


    }
}

namespace AttendanceManagement.tests
{
    class RegularizationRequestController : RegularizationController
    {
        public RegularizationRequestController(IRegularizationRequestServices services) : base(services)
        {
        }
    }
}