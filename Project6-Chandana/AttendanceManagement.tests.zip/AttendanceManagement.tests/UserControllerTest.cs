﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Controllers;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using AttendanceManagement.Controllers;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
namespace AttendenceManagementSystem.Test.ControllersTest
{
    public class UserControllerTest
    {
        [Fact]
        public async Task Register_ReturnsConflict_WhenUserAlreadyExists()
        {
            // Arrange
            var mockUserServices = new Mock<IUserServices>();
            var userDto = new UserCommandModel
            {
                Email = "test@example.com",
               // Role = Role.User
            };

            // Mock GetUserByEmailAsync to return an existing User
            mockUserServices.Setup(s => s.GetUserByEmailAsync(It.IsAny<string>()))
                .ReturnsAsync(new User { UserId = 1, Email = "test@example.com" });

            var controller = new UserControllers(mockUserServices.Object);

            // Act
            var result = await controller.Register(userDto);

            // Assert
            var conflictResult = Assert.IsType<ConflictObjectResult>(result);
            Assert.Equal("A user with this email already exists.", conflictResult.Value);
        }

        [Fact]
        public async Task Register_ReturnsUnauthorized_WhenRoleIsAdmin()
        {
            // Arrange
            var mockUserServices = new Mock<IUserServices>();
            var userDto = new UserCommandModel
            {
                Email = "admin@example.com",
                //Role = Role.Admin
            };

            // Mock GetUserByEmailAsync to return null (no existing user)
            mockUserServices.Setup(s => s.GetUserByEmailAsync(It.IsAny<string>()))
                .ReturnsAsync((User)null);

            var controller = new UserControllers(mockUserServices.Object);

            // Act
            var result = await controller.Register(userDto);

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
            Assert.Equal("Only an existing Admin can register new Admins.", unauthorizedResult.Value);
        }

        [Fact]
        public async Task Register_ReturnsOk_WhenUserIsSuccessfullyCreated()
        {
            // Arrange
            var mockUserServices = new Mock<IUserServices>();
            var userDto = new UserCommandModel
            {
                Email = "newuser@example.com",
               // Role = Role.User
            };

            // Mock GetUserByEmailAsync to return null (no existing user)
            mockUserServices.Setup(s => s.GetUserByEmailAsync(It.IsAny<string>()))
                .ReturnsAsync((User)null);

            // Mock CreateUserAsync to return a success message
            mockUserServices.Setup(s => s.CreateUserAsync(It.IsAny<UserCommandModel>()))
                .ReturnsAsync("User created successfully");

            var controller = new UserControllers(mockUserServices.Object);

            // Act
            var result = await controller.Register(userDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("User created successfully", okResult.Value);
        }

        [Fact]
        public async Task Register_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var mockUserServices = new Mock<IUserServices>();
            var userDto = new UserCommandModel(); // Missing required fields for validation

            var controller = new UserControllers(mockUserServices.Object);
            controller.ModelState.AddModelError("Email", "The Email field is required.");

            // Act
            var result = await controller.Register(userDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<SerializableError>(badRequestResult.Value);
        }


        [Fact]
        public async Task UpdateProfile_ReturnsOk_WhenProfileUpdateIsSuccessful()
        {
            // Arrange
            var mockUserServices = new Mock<IUserServices>();
            var userUpdateDTO = new UserCommandModel { Email = "updated@example.com", Name = "Updated Name" };
            mockUserServices.Setup(s => s.UpdateUserAsync(It.IsAny<int>(), It.IsAny<UserCommandModel>()))
                            .ReturnsAsync("Profile updated successfully.");
            var controller = new UserControllers(mockUserServices.Object);

            var userIdClaim = new Claim(ClaimTypes.NameIdentifier, "1");
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[] { userIdClaim }))
            };

            // Act
            var result = await controller.UpdateProfile(userUpdateDTO);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Profile updated successfully.", okResult.Value);
        }

    }

}