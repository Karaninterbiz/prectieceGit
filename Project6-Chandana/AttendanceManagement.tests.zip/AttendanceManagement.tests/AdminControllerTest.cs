﻿using AttendanceManagement.Controllers;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Data;
using System.Threading.Tasks;
using Xunit;

namespace AttendenceManagementSystem.Test.ControllersTest
{
    public class AdminControllersTest
    {
        private readonly Mock<IAdminServices> _mockAdminServices;
        private readonly AdminController _adminController;

        public AdminControllersTest()
        {
            _mockAdminServices = new Mock<IAdminServices>();
            _adminController = new AdminController(_mockAdminServices.Object);
        }

        //UNIT TESTS FOR GetAllUsers
        [Fact]
        public async Task GetAllUsers_ReturnsOkResult_WhenUsersExist()
        {
            // Arrange
            _mockAdminServices.Setup(s => s.GetAllUsersAsync())
                              .ReturnsAsync("List of users");

            // Act
            var result = await _adminController.GetAllUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("List of users", okResult.Value);
        }

        [Fact]
        public async Task GetAllUsers_ReturnsOkResult_WhenNoUsersExist()
        {
            // Arrange
            _mockAdminServices.Setup(s => s.GetAllUsersAsync())
                              .ReturnsAsync("No users found.");

            // Act
            var result = await _adminController.GetAllUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("No users found.", okResult.Value);
        }


        [Fact]
        public async Task GetAllUsers_ReturnsOkResult_WithEmptyList()
        {
            // Arrange
            _mockAdminServices.Setup(s => s.GetAllUsersAsync())
                              .ReturnsAsync("");

            // Act
            var result = await _adminController.GetAllUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("", okResult.Value);
        }

        [Fact]
        public async Task GetAllUsers_CallsServiceOnce()
        {
            // Arrange
            _mockAdminServices.Setup(s => s.GetAllUsersAsync())
                              .ReturnsAsync("List of users");

            // Act
            await _adminController.GetAllUsers();

            // Assert
            _mockAdminServices.Verify(s => s.GetAllUsersAsync(), Times.Once);
        }
        //UNIT TESTS FOR AssignRole
        [Fact]
        public async Task AssignRole_ReturnsOkResult_WhenRoleAssignedSuccessfully()
        {
            // Arrange
            int userId = 1;
            Role role = Role.Admin;
            _mockAdminServices.Setup(s => s.AssignRoleToUserAsync(userId, role))
                              .ReturnsAsync("Role assigned successfully.");

            // Act
            var result = await _adminController.AssignRole(userId, role);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Role assigned successfully.", okResult.Value);
        }



        [Fact]
        public async Task AssignRole_ReturnsOkResult_WithInvalidRole()
        {
            // Arrange
            int userId = 1;
            Role role = (Role)999; // Invalid role
            _mockAdminServices.Setup(s => s.AssignRoleToUserAsync(userId, role))
                              .ReturnsAsync("Invalid role provided.");

            // Act
            var result = await _adminController.AssignRole(userId, role);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Invalid role provided.", okResult.Value);
        }

        [Fact]
        public async Task AssignRole_CallsServiceOnce()
        {
            // Arrange
            int userId = 1;
            Role role = Role.User;
            _mockAdminServices.Setup(s => s.AssignRoleToUserAsync(userId, role))
                              .ReturnsAsync("Role assigned successfully.");

            // Act
            await _adminController.AssignRole(userId, role);

            // Assert
            _mockAdminServices.Verify(s => s.AssignRoleToUserAsync(userId, role), Times.Once);
        }

        [Fact]
        public async Task AssignRole_ReturnsBadRequest_WhenUserIdIsInvalid()
        {
            // Arrange
            int userId = -1;
            Role role = Role.User;
            _mockAdminServices.Setup(s => s.AssignRoleToUserAsync(userId, role))
                              .ReturnsAsync("Invalid user ID.");

            // Act
            var result = await _adminController.AssignRole(userId, role);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Invalid user ID.", okResult.Value);
        }

        [Fact]
        public async Task GetUserAttendance_ReturnsOkResult_WhenDataExists()
        {
            // Arrange
            int userId = 1;
            var attendanceData = "User attendance data";
            _mockAdminServices.Setup(s => s.GetUserAttendanceAsync(userId))
                              .ReturnsAsync(attendanceData);

            // Act
            var result = await _adminController.GetUserAttendance(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(attendanceData, okResult.Value);
        }

        [Fact]
        public async Task GetUserAttendance_ReturnsOkResult_WhenNoDataExists()
        {
            // Arrange
            int userId = 1;
            _mockAdminServices.Setup(s => s.GetUserAttendanceAsync(userId))
                              .ReturnsAsync("No attendance data found.");

            // Act
            var result = await _adminController.GetUserAttendance(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("No attendance data found.", okResult.Value);
        }

        [Fact]
        public async Task GetAttendanceBetweenDates_ReturnsOkResult_WhenDataExists()
        {
            // Arrange
            int userId = 1;
            var startDate = DateTime.Now.AddDays(-10);
            var endDate = DateTime.Now;
            var attendanceData = "Attendance data between dates";
            _mockAdminServices.Setup(s => s.GetAttendanceBetweenDatesAsync(userId, startDate, endDate))
                              .ReturnsAsync(attendanceData);

            // Act
            var result = await _adminController.GetAttendanceBetweenDates(userId, startDate, endDate);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(attendanceData, okResult.Value);
        }

        [Fact]
        public async Task GetAttendanceBetweenDates_ReturnsOkResult_WhenNoDataExists()
        {
            // Arrange
            int userId = 1;
            var startDate = DateTime.Now.AddDays(-10);
            var endDate = DateTime.Now;
            _mockAdminServices.Setup(s => s.GetAttendanceBetweenDatesAsync(userId, startDate, endDate))
                              .ReturnsAsync("No attendance data found between dates.");

            // Act
            var result = await _adminController.GetAttendanceBetweenDates(userId, startDate, endDate);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("No attendance data found between dates.", okResult.Value);
        }




    }
}
