﻿namespace AttendanceManagement.Helper
{
    public class AccessValidation
    {

    }
}
