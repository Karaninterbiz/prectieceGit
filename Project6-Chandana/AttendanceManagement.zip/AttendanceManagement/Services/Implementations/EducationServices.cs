﻿using AttendanceManagement.Data;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;

using AttendanceManagement.Services.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Services.Implementations
{
    public class EducationServices:IEducationServices
    {
        private readonly Project6Context _context;

        public EducationServices(Project6Context context)
        {
            _context = context;
        }
        public async Task<string> AddEducation(int userId, EducationCommandModels educationDTO)
        {
            var education = new Education
            {
                UserId = userId,
                Degree = educationDTO.Degree,
                FieldOfStudy = educationDTO.FieldOfStudy,
                Institution = educationDTO.Institution,
                YearOfCompletion = educationDTO.YearOfCompletion,
                Gpa = educationDTO.Gpa,
                GradeType = educationDTO.GradeType,
                Achievements = educationDTO.Achievements,
                CreatedAt = DateTime.UtcNow
            };

            await _context.Educations.AddAsync(education);
            await _context.SaveChangesAsync();

            return "Education record added successfully.";
        }

        public async Task<string> UpdateEducation(int userId, EducationCommandModels educationDTO, int educationID)
        {
            var education = await _context.Educations.FirstOrDefaultAsync(e => e.UserId == userId && e.EducationId == educationID);
            if (education == null)
            {
                throw new Exception("Education record not found or unauthorized access.");
            }

            education.Degree = educationDTO.Degree;
            education.FieldOfStudy = educationDTO.FieldOfStudy;
            education.Institution = educationDTO.Institution;
            education.YearOfCompletion = educationDTO.YearOfCompletion;
            education.Gpa = educationDTO.Gpa;
            education.GradeType = educationDTO.GradeType;
            education.Achievements = educationDTO.Achievements;
            education.UpdatedAt = DateTime.UtcNow;

            _context.Educations.Update(education);
            await _context.SaveChangesAsync();

            return "Education record updated successfully.";
        }

        public async Task<string> DeleteEducation(int userId, int educationID)
        {
            var education = await _context.Educations.FirstOrDefaultAsync(e => e.UserId == userId && e.EducationId == educationID);
            if (education == null)
            {
                throw new Exception("Education record not found or unauthorized access.");
            }

            _context.Educations.Remove(education);
            await _context.SaveChangesAsync();

            return "Education record deleted successfully.";
        }
    }
}
