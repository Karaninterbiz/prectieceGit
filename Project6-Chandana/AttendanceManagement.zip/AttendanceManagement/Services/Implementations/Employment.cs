﻿using AttendanceManagement.Data;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Services.Implementations
{
    public class EmploymentRepository:IEmploymentServices
    {
        private readonly Project6Context _context;

        public EmploymentRepository(Project6Context context)
        {
            _context = context;
        }
        public async Task<string> AddEmployment(int userId,  EmployCommandModel  EmployCommandModel)
        {
            var employment = new Employment
            {
                UserId = userId,
                JobTitle =  EmployCommandModel.JobTitle,
                CompanyName =  EmployCommandModel.CompanyName,
                Location =  EmployCommandModel.Location,
                StartDate =  EmployCommandModel.StartDate,
                EndDate =  EmployCommandModel.EndDate,
                IsCurrentJob =  EmployCommandModel.IsCurrentJob,
                Description =  EmployCommandModel.Description,
                Responsibilities =  EmployCommandModel.Responsibilities,
                CreatedAt = DateTime.UtcNow
            };

            await _context.Employments.AddAsync(employment);
            await _context.SaveChangesAsync();

            return "Employment record added successfully.";
        }

        public async Task<string> UpdateEmployment(int userId,  EmployCommandModel  EmployCommandModel, int employmentID)
        {
            var employment = await _context.Employments.FirstOrDefaultAsync(e => e.UserId == userId && e.EmploymentId == employmentID);
            if (employment == null)
            {
                throw new Exception("Employment record not found or unauthorized access.");
            }

            employment.CompanyName =  EmployCommandModel.CompanyName;
            employment.Location =  EmployCommandModel.Location;
            employment.StartDate =  EmployCommandModel.StartDate;
            employment.EndDate =  EmployCommandModel.EndDate;
            employment.IsCurrentJob =  EmployCommandModel.IsCurrentJob;
            employment.Description =  EmployCommandModel.Description;
            employment.Responsibilities =  EmployCommandModel.Responsibilities;
            employment.UpdatedAt = DateTime.UtcNow;

            _context.Employments.Update(employment);
            await _context.SaveChangesAsync();

            return "Employment record updated successfully.";
        }

        public async Task<string> DeleteEmployment(int userId, int employmentID)
        {
            var employment = await _context.Employments.FirstOrDefaultAsync(e => e.UserId == userId && e.EmploymentId == employmentID);
            if (employment == null)
            {
                throw new Exception("Employment record not found or unauthorized access.");
            }

            _context.Employments.Remove(employment);
            await _context.SaveChangesAsync();

            return "Employment record deleted successfully.";
        }
    }
}
