﻿using AttendanceManagement.Data;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using AttendanceManagement.CommandModels;

namespace AttendanceManagement.Services.Implementations
{
    public class AdminServices : IAdminServices
    {
        private readonly Project6Context _context;

        public AdminServices(Project6Context context)
        {
            _context = context;
        }

        public async Task<string> GetAllUsersAsync()
        {
            var users = await _context.Users.ToListAsync();
            if (users.Count == 0)
                return "No users found.";

            return string.Join("\n", users.Select(u => $"ID: {u.UserId}, Name: {u.Name}, Role: {u.Role}"));
        }

        public async Task<string> CreateUserAsync(AdminCammandModels adminDTO)
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == adminDTO.Email);
            if (existingUser != null)
                return "User with this email already exists.";

            var newUser = new User
            {
                Name = adminDTO.Name,
                Email = adminDTO.Email,
                Password = adminDTO.Password,
                Role = adminDTO.Role.ToString(),
                Gender = adminDTO.Gender
            };
            if (!string.IsNullOrEmpty(newUser.Password))
            {
                var passwordHasher = new PasswordHasher<User>();
                newUser.Password = passwordHasher.HashPassword(newUser, newUser.Password);
            }
            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();
            return $"User '{newUser.Name}' created successfully with ID: {newUser.UserId}.";
        }

        public async Task<string> AssignRoleToUserAsync(int userId, Role role)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                return "User not found.";

            user.Role = role.ToString();
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return $"Role '{role}' assigned successfully to User ID: {user.Name}.";
        }

        public async Task<string> GetUserAttendanceAsync(int userId)
        {
            var attendanceRecords = await _context.Attendances
                .Where(a => a.UserId == userId)
                .Select(a => new AttendanceCommandModel
                {
                    AttendanceDate = a.AttendanceDate,
                    Status = a.Status
                })
                .ToListAsync();

            if (!attendanceRecords.Any())
                return $"No attendance records found for User ID: {userId}.";

            return string.Join("\n", attendanceRecords.Select(a => $"Date: {a.AttendanceDate}, Status: {a.Status}"));
        }

        public async Task<string> GetAttendanceBetweenDatesAsync(int userId, DateTime startDate, DateTime endDate)
        {
            var attendanceRecords = await _context.Attendances
                .Where(a => a.UserId == userId && a.AttendanceDate >= startDate && a.AttendanceDate <= endDate)
                .Select(a => new AttendanceCommandModel
                {
                    AttendanceDate = a.AttendanceDate,
                    Status = a.Status
                })
                .ToListAsync();

            if (!attendanceRecords.Any())
                return $"No attendance records found for User ID: {userId} between {startDate} and {endDate}.";

            return string.Join("\n", attendanceRecords.Select(a => $"User ID: {userId} Date: {a.AttendanceDate}, Status: {a.Status}"));
        }

        public async Task<string> UpdateAttendanceAsync(AttendanceCommandModel attendanceDTO)
        {
            var attendance = await _context.Attendances
                .FirstOrDefaultAsync(a => a.UserId == attendanceDTO.UserId && a.AttendanceDate == attendanceDTO.AttendanceDate);

            if (attendance == null)
                return "Attendance record not found.";

            attendance.Status = attendanceDTO.Status;
            _context.Attendances.Update(attendance);
            await _context.SaveChangesAsync();

            return $"Attendance for User ID: {attendanceDTO.UserId} on {attendanceDTO.AttendanceDate} updated successfully.";
        }

        public async Task<string> GetAllAttendanceRecordsAsync()
        {
            var attendanceRecords = await _context.Attendances
                .Select(a => new AttendanceCommandModel
                {
                    UserId = a.UserId,
                    AttendanceDate = a.AttendanceDate,
                    Status = a.Status
                })
                .ToListAsync();

            if (!attendanceRecords.Any())
                return "No attendance records found.";

            return string.Join("\n", attendanceRecords.Select(a => $"User ID: {a.UserId}, Date: {a.AttendanceDate}, Status: {a.Status}"));
        }
    }
}
