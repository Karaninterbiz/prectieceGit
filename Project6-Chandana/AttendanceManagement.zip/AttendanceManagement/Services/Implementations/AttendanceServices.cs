﻿using AttendanceManagement.Data;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;

using Microsoft.EntityFrameworkCore;
namespace AttendanceManagement.Services.Implementations
{
    public class AttendanceServices : IAttendanceServices
    {
        private readonly Project6Context _context;

        public AttendanceServices(Project6Context context)
        {
            _context = context;
        }

        // Fetch attendance for a specific user
        public async Task<List<Attendance>> GetAttendanceByUserIdAsync(int userId)
        {
            return await _context.Attendances
                                 .Where(a => a.UserId == userId)
                                 .OrderBy(a => a.AttendanceDate)
                                 .ToListAsync();
        }

        // Add new attendance record for a user
        public async Task AddAsync(Attendance attendance)
        {
            await _context.Attendances.AddAsync(attendance);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Attendance>> GetAttendanceByUserIdAndMonthAsync(int userId, int month, int year)
        {
            // Fetch attendance records for the specific user, month, and year
            return await _context.Attendances
                .Where(a => a.UserId == userId && a.AttendanceDate.Month == month && a.AttendanceDate.Year == year)
                .ToListAsync();
        }
    }
}
