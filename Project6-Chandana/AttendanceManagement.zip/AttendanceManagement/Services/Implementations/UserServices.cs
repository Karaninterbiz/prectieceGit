﻿using AttendanceManagement.Data;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AttendanceManagement.CommandModels;


namespace AttendanceManagement.Services.Implementations
{
    public class UserServices : IUserServices
    {
        private readonly Project6Context _context;
        private readonly IConfiguration _configuration;
        public UserServices(Project6Context context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<string> CreateUserAsync(UserCommandModel userDTO)
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == userDTO.Email);
            if (existingUser != null)
            {
                throw new Exception("User with this email already exists.");
            }

            var user = new User
            {
                Name = userDTO.Name,
                Email = userDTO.Email,
                Password = userDTO.Password,
                Role = "User",
                Gender = userDTO.Gender,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            if (!string.IsNullOrEmpty(user.Password))
            {
                var passwordHasher = new PasswordHasher<User>();
                user.Password = passwordHasher.HashPassword(user, user.Password);
            }

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return $"User registered successfully: {user.Name}";
        }

        public async Task<string> UpdateUserAsync(int userId, UserCommandModel userDTO)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                throw new Exception("User not found.");
            }

            user.Name = userDTO.Name;
            user.Email = userDTO.Email;
            user.Password = userDTO.Password;
            user.Gender = userDTO.Gender;
            user.UpdatedAt = DateTime.UtcNow;

            if (!string.IsNullOrEmpty(user.Password))
            {
                var passwordHasher = new PasswordHasher<User>();
                user.Password = passwordHasher.HashPassword(user, user.Password);
            }
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return "User profile updated successfully.";
        }

        public async Task<string> LoginAsync(LoginDTO loginDTO)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginDTO.Email);
            if (user == null)
                throw new Exception("Invalid email or password.");

            var passwordHasher = new PasswordHasher<User>();
            if (passwordHasher.VerifyHashedPassword(user, user.Password, loginDTO.Password) == PasswordVerificationResult.Failed)
                throw new Exception("Invalid email or password.");

            return GenerateToken(user);
        }

        public UserProfileDto GetUserProfile(int userId)
        {
            var user = _context.Users
                .Include(u => u.Addresses)
                .Include(u => u.Educations)
                .Include(u => u.Employments)
                .FirstOrDefault(u => u.UserId == userId);

            if (user == null) return null;

            return new UserProfileDto
            {
                UserId = user.UserId,
                Name = user.Name,
                Email = user.Email,

                Addresses = user.Addresses.Select(a => new AddressCommandModel
                {

                    AddressType = a.AddressType,
                    Street = a.Street,
                    City = a.City,
                    State = a.State,
                    ZipCode = a.ZipCode,
                    Country = a.Country
                }).ToList(),
                Educations = user.Educations.Select(e => new EducationCommandModels
                {

                    Degree = e.Degree,
                    FieldOfStudy = e.FieldOfStudy,
                    Institution = e.Institution,
                    Gpa = e.Gpa,
                    GradeType = e.GradeType,
                    Achievements = e.Achievements,
                    YearOfCompletion = e.YearOfCompletion
                }).ToList(),
                Employments = user.Employments.Select(em => new  EmployCommandModel
                {

                    JobTitle = em.JobTitle,
                    CompanyName = em.CompanyName,
                    Location = em.Location,
                    Description = em.Description,
                    Responsibilities = em.Responsibilities,
                    StartDate = em.StartDate,
                    EndDate = em.EndDate,
                    IsCurrentJob = em.IsCurrentJob
                }).ToList()
            };
        }
        public async Task StoreTokenAsync(string token, int userId)
        {
            var userSession = new UserSession
            {
                Token = token,
                UserId = userId
            };

            _context.UserSessions.Add(userSession);
            await _context.SaveChangesAsync();
        }

        public async Task<string> ChangePasswordAsync(int userId, PasswordChangeDTO passwordChangeDTO)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                throw new Exception("User not found.");
            }

            var passwordHasher = new PasswordHasher<User>();
            if (passwordHasher.VerifyHashedPassword(user, user.Password, passwordChangeDTO.CurrentPassword) == PasswordVerificationResult.Failed)
            {
                throw new Exception("Current password is incorrect.");
            }

            user.Password = passwordHasher.HashPassword(user, passwordChangeDTO.NewPassword);
            await _context.SaveChangesAsync();

            return "Password changed successfully.";
        }


        public async Task<bool> DeleteUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return true;
        }


        private string GenerateToken(User user)
        {
            var jwtSettings = _configuration.GetSection("JwtSettings");
            var secretKey = jwtSettings["Secret"];
            var issuer = jwtSettings["Issuer"];
            var audience = jwtSettings["Audience"];

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
    {
        new Claim(ClaimTypes.Email, user.Email),
        new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
        new Claim(ClaimTypes.Role, user.Role) // Ensure Role is set here
    };

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


    }
}

