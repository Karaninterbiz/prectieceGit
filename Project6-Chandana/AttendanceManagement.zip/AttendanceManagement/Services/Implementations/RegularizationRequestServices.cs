﻿using AttendanceManagement.Data;
using AttendanceManagement.Model;

using AttendanceManagement.Services.Abstractions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AttendanceManagement.Services.Implementations
{
    public class RegularizationRequestServices : IRegularizationRequestServices
    {
        private readonly Project6Context _context;

        public RegularizationRequestServices(Project6Context context)
        {
            _context = context;
        }

        public async Task<IEnumerable<RegularizationRequest>> GetRegularizationRequestsByUserIdAsync(int userId)
        {
            return await _context.RegularizationRequests
                .Where(r => r.UserId == userId)
                .ToListAsync();
        }

        public async Task<RegularizationRequest> CreateRegularizationRequestAsync(int userId, DateTime attendanceDate, string reason)
        {
            // Check if a request for the same date already exists
            var existingRequest = await _context.RegularizationRequests
                .FirstOrDefaultAsync(r => r.UserId == userId && r.Attendance.AttendanceDate.Date == attendanceDate.Date);

            if (existingRequest != null)
            {
                throw new InvalidOperationException($"You have already applied for a regularization request for the date {attendanceDate.ToString("yyyy-MM-dd")}.");
            }

            //  only the date parts are compared
            var attendance = await _context.Attendances
                .FirstOrDefaultAsync(a => a.UserId == userId && a.AttendanceDate.Date == attendanceDate.Date);

            if (attendance == null)
            {
                throw new InvalidOperationException($"Attendance not found for the date {attendanceDate.ToString("yyyy-MM-dd")}.");
            }

            
            var request = new RegularizationRequest
            {
                UserId = userId,
                AttendanceId = attendance.AttendanceId,
                Reason = reason,
                Status = "Pending",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.RegularizationRequests.Add(request);
            await _context.SaveChangesAsync();
            return request;
        }



        public async Task<RegularizationRequest> AdminCreateRequestAsync(int adminId, int userId, int attendanceId, string reason)
        {
            var request = new RegularizationRequest
            {
                AdminId = adminId,
                UserId = userId,
                AttendanceId = attendanceId,
                Reason = reason,
                Status = "Pending",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.RegularizationRequests.Add(request);
            await _context.SaveChangesAsync();
            return request;
        }

        public async Task<bool> ApproveOrDenyRequestAsync(int requestId, bool isApproved, int adminId)
        {
            var request = await _context.RegularizationRequests
                .FirstOrDefaultAsync(r => r.RequestId == requestId);

            if (request == null)
                throw new KeyNotFoundException($"Regularization request with ID {requestId} not found.");

            request.Status = isApproved ? "Approved" : "Denied";
            request.AdminId = adminId;
            request.UpdatedAt = DateTime.Now;

            _context.RegularizationRequests.Update(request);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<RegularizationRequest> GetRegularizationRequestByIdAsync(int requestId)
        {
            var request = await _context.RegularizationRequests
                .FirstOrDefaultAsync(r => r.RequestId == requestId);

            if (request == null)
                throw new KeyNotFoundException($"Request with ID {requestId} not found.");

            return request;
        }

        public async Task<IEnumerable<RegularizationRequest>> GetPendingRegularizationRequestsAsync()
        {
            return await _context.RegularizationRequests
                .Where(r => r.Status == "Pending")
                .ToListAsync();
        }
    }
}
