﻿using AttendanceManagement.Data;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Services.Implementations
{
    public class AddressServices: IAddressServices
    {
        private readonly Project6Context _context;

        public AddressServices(Project6Context context)
        {
            _context = context;
        }

        public async Task<string> AddAddress(int userId, AddressCommandModel addressDTO)
        {

            var address = new Address
            {
                UserId = userId,
                AddressType = addressDTO.AddressType,
                Street = addressDTO.Street,
                City = addressDTO.City,
                State = addressDTO.State,
                ZipCode = addressDTO.ZipCode,
                Country = addressDTO.Country,
                CreatedAt = DateTime.UtcNow
            };

            await _context.Addresses.AddAsync(address);
            await _context.SaveChangesAsync();

            return "Address added successfully.";
        }

        public async Task<string> UpdateAddress(int addressId, int userId, AddressCommandModel addressDTO)
        {
            var address = await _context.Addresses.FirstOrDefaultAsync(a => a.AddressId == addressId && a.UserId == userId);
            if (address == null)
            {
                throw new Exception("Address not found or unauthorized access.");
            }

            address.AddressType = addressDTO.AddressType.ToString();
            address.Street = addressDTO.Street;
            address.City = addressDTO.City;
            address.State = addressDTO.State;
            address.ZipCode = addressDTO.ZipCode;
            address.Country = addressDTO.Country;
            address.UpdatedAt = DateTime.UtcNow;

            _context.Addresses.Update(address);
            await _context.SaveChangesAsync();

            return "Address updated successfully.";
        }

        public async Task<string> DeleteAddress(int addressId, int userId)
        {
            var address = await _context.Addresses.FirstOrDefaultAsync(a => a.AddressId == addressId && a.UserId == userId);
            if (address == null)
            {
                throw new Exception("Address not found or unauthorized access.");
            }

            _context.Addresses.Remove(address);
            await _context.SaveChangesAsync();

            return "Address deleted successfully.";
        }
    }
}
