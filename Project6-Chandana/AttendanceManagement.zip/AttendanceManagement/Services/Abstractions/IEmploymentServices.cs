﻿using AttendanceManagement.CommandModels;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IEmploymentServices
    {
        Task<string> AddEmployment(int userId, EmployCommandModel employmentDTO);
        Task<string> UpdateEmployment(int userId, EmployCommandModel employmentDTO, int employmentID);
        Task<string> DeleteEmployment(int userId, int employmentID);
    }
}
