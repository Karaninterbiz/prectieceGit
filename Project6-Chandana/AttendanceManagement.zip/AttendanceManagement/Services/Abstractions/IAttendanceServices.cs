﻿using AttendanceManagement.Model;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IAttendanceServices
    {
        Task<List<Attendance>> GetAttendanceByUserIdAsync(int userId);
        Task<List<Attendance>> GetAttendanceByUserIdAndMonthAsync(int userId, int month, int year);
        Task AddAsync(Attendance attendance);
    }
}
