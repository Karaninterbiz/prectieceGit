﻿using AttendanceManagement.CommandModels;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IAddressServices
    {
        Task<string> AddAddress(int userId, AddressCommandModel addressDTO);
        Task<string> UpdateAddress(int addressId, int userId, AddressCommandModel addressDTO);
        Task<string> DeleteAddress(int addressId, int userId);
    }
}
