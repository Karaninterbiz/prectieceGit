﻿using AttendanceManagement.CommandModels;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IEducationServices
    {
        Task<string> AddEducation(int userId, EducationCommandModels educationDTO);
        Task<string> UpdateEducation(int userId, EducationCommandModels educationDTO, int educationID);
        Task<string> DeleteEducation(int userId, int educationID);
    }
}
