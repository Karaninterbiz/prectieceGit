﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IUserServices
    {
        Task<User> GetUserByEmailAsync(string email);
        Task<string> CreateUserAsync(UserCommandModel userDTO);  
        Task<string> UpdateUserAsync(int userId, UserCommandModel userDTO);
        Task<string> LoginAsync(LoginDTO loginDTO);
        Task<string> ChangePasswordAsync(int userId, PasswordChangeDTO passwordChangeDTO);
        Task StoreTokenAsync(string token, int userId);
        UserProfileDto GetUserProfile(int userId);
        Task<bool> DeleteUserAsync(int userId);  
    }
}
