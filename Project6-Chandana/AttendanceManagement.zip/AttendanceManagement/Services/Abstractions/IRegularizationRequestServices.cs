﻿using AttendanceManagement.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IRegularizationRequestServices
    {
        Task<IEnumerable<RegularizationRequest>> GetRegularizationRequestsByUserIdAsync(int userId);
        Task<RegularizationRequest> CreateRegularizationRequestAsync(int userId, DateTime attendanceDate, string reason);
        Task<RegularizationRequest> AdminCreateRequestAsync(int adminId, int userId, int attendanceId, string reason);
        Task<bool> ApproveOrDenyRequestAsync(int requestId, bool isApproved, int adminId);
        Task<RegularizationRequest> GetRegularizationRequestByIdAsync(int requestId);
        Task<IEnumerable<RegularizationRequest>> GetPendingRegularizationRequestsAsync();
    }
}
