﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;

namespace AttendanceManagement.Services.Abstractions
{
    public interface IAdminServices
    {
        Task<string> GetAllUsersAsync();
        Task<string> CreateUserAsync(AdminCammandModels adminDTO);
        Task<string> AssignRoleToUserAsync(int userId, Role role);
        Task<string> GetUserAttendanceAsync(int userId);
        Task<string> GetAttendanceBetweenDatesAsync(int userId, DateTime startDate, DateTime endDate);
        Task<string> UpdateAttendanceAsync(AttendanceCommandModel attendanceDTO);
        Task<string> GetAllAttendanceRecordsAsync();
        //Task UpdateAttendanceAsync(AttendanceCommandModel attendanceDTO);
    }
}
