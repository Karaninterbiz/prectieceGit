﻿using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.CommandModels
{
    public class EmployCommandModel
    {
        [Required]
        [StringLength(100)]
        public string JobTitle { get; set; } = null!;

        [Required]
        [StringLength(255)]
        public string CompanyName { get; set; } = null!;

        [StringLength(100)]
        public string? Location { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; } = null;

        [Required]
        public bool? IsCurrentJob { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(500)]
        public string? Responsibilities { get; set; }
    }
}
