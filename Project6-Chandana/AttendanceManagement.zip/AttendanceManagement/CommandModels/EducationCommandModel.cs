﻿using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.CommandModels
{
    public class EducationCommandModels
    {
      
            [Required]
            [StringLength(100)]
            public string Degree { get; set; } = null!;

            [StringLength(100)]
            public string? FieldOfStudy { get; set; }

            [Required]
            [StringLength(150)]
            public string Institution { get; set; } = null!;

            [Required]
            [Range(1900, 2100, ErrorMessage = "Year of Completion must be between 1900 and 2100.")]
            public short YearOfCompletion { get; set; }

            [Range(0.0, 4.0, ErrorMessage = "GPA must be between 0.0 and 4.0.")]
            public decimal? Gpa { get; set; }

            [StringLength(50)]
            public string? GradeType { get; set; }

            [StringLength(500)]
            public string? Achievements { get; set; }
        }
    }


