﻿namespace AttendanceManagement.CommandModels
{
    public class RegularizationCommandModel
    {
        public string Reason { get; set; } = string.Empty;
        public DateTime AttendanceDate { get; set; }
    }
}
