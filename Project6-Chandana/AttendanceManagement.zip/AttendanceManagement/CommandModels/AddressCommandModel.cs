﻿using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.CommandModels
{
    public class AddressCommandModel
    {

     
            [Required]
            public string AddressType { get; set; }

            [Required]
            [StringLength(100)]
            public string Street { get; set; }

            [Required]
            [StringLength(50)]
            public string City { get; set; }

            [Required]
            [StringLength(50)]
            public string State { get; set; }

            [Required]

            public string ZipCode { get; set; }

            [Required]
            [StringLength(50)]
            public string Country { get; set; }
        
    }
}