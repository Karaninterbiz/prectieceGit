﻿namespace AttendanceManagement.CommandModels
{
    public class MonthlyReportCommandModel
    {
        public int ReportId { get; set; }

        public int UserId { get; set; }

        public DateOnly MonthYear { get; set; }

        public int TotalDays { get; set; }

        public int PresentDays { get; set; }

        public int AbsentDays { get; set; }

        public int? LeaveDays { get; set; }

        public int? LateDays { get; set; }

        public DateTime? GeneratedAt { get; set; }
    }
}
