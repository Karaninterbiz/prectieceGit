﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AttendanceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,User")]
    public class AddressControllers : ControllerBase
    {
        private readonly IAddressServices _addressservices;

        public AddressControllers(IAddressServices addressServices)
        {
            _addressservices = addressServices;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddAddress([FromBody] AddressCommandModel addressDTO)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _addressservices.AddAddress(userId, addressDTO);
            return Ok(new { Message = result });
        }

        [HttpPut("update/{addressId}")]
        public async Task<IActionResult> UpdateAddress(int addressId, [FromBody] AddressCommandModel addressDTO)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _addressservices.UpdateAddress(addressId, userId, addressDTO);
            return Ok(new { Message = result });
        }

        [HttpDelete("delete/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _addressservices.DeleteAddress(addressId, userId);
            return Ok(new { Message = result });
        }
    }
}

