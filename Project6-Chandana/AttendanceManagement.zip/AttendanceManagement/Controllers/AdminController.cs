﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AttendanceManagement.Controllers
{ 
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminServices _adminServices;

        public AdminController(IAdminServices adminServices)
        {
            _adminServices = adminServices;
        }
       // [AllowAnonymous]
        [HttpGet("users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var result = await _adminServices.GetAllUsersAsync();
            return Ok(result);
        }

        [HttpPost("createUser")]
        public async Task<IActionResult> CreateUser([FromBody] AdminCammandModels adminDTO)
        {
            var result = await _adminServices.CreateUserAsync(adminDTO);
            return Ok(result);
        }

        [HttpPut("assignRole/{userId}")]
        public async Task<IActionResult> AssignRole(int userId, [FromBody] Role role)
        {
            var result = await _adminServices.AssignRoleToUserAsync(userId, role);
            return Ok(result);
        }

        [HttpGet("attendance/{userId}")]
        public async Task<IActionResult> GetUserAttendance(int userId)
        {
            var result = await _adminServices.GetUserAttendanceAsync(userId);
            return Ok(result);
        }

        [HttpGet("attendance/{userId}/{startDate}/{endDate}")]
        public async Task<IActionResult> GetAttendanceBetweenDates(int userId, DateTime startDate, DateTime endDate)
        {
            var result = await _adminServices.GetAttendanceBetweenDatesAsync(userId, startDate, endDate);
            return Ok(result);
        }

        [HttpPut("updateAttendance")]
        public async Task<IActionResult> UpdateAttendance([FromBody] AttendanceCommandModel attendanceDTO)
        {
            var result = await _adminServices.UpdateAttendanceAsync(attendanceDTO);
            return Ok(result);
        }


        [HttpGet("allAttendance")]
        public async Task<IActionResult> GetAllAttendanceRecords()
        {
            var result = await _adminServices.GetAllAttendanceRecordsAsync();
            return Ok(result);
        }
    }
}
