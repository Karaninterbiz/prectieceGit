﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AttendenceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EmploymentControllers : ControllerBase
    {
        private readonly IEmploymentServices _employmentServices;

        public EmploymentControllers(IEmploymentServices employmentServices)
        {
            _employmentServices = employmentServices;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddEmployment([FromBody]  EmployCommandModel  EmployCommandModel)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _employmentServices.AddEmployment(userId,  EmployCommandModel);
            return Ok(new { Message = result });
        }

        [HttpPut("update/{employmentID}")]
        public async Task<IActionResult> UpdateEmployment([FromBody]  EmployCommandModel  EmployCommandModel, int employmentID)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _employmentServices.UpdateEmployment(userId,  EmployCommandModel, employmentID);
            return Ok(new { Message = result });
        }

        [HttpDelete("delete")]
        public async Task<IActionResult> DeleteEmployment(int employmentID)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _employmentServices.DeleteEmployment(userId, employmentID);
            return Ok(new { Message = result });
        }
    }
}
