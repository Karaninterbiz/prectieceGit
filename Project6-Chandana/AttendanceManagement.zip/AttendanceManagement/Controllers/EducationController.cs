﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AttendenceManagement.Controllers
{
    [Authorize(Roles = "Admin,User")]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EducationControllers : ControllerBase
    {
        private readonly IEducationServices _educationServices;

        public EducationControllers(IEducationServices educationServices)
        {
            _educationServices = educationServices;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddEducation([FromBody] EducationCommandModels educationDTO)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _educationServices.AddEducation(userId, educationDTO);
            return Ok(new { Message = result });
        }

        [HttpPut("update/{educationID}")]
        public async Task<IActionResult> UpdateEducation([FromBody] EducationCommandModels educationDTO, int educationID)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _educationServices.UpdateEducation(userId, educationDTO, educationID);
            return Ok(new { Message = result });
        }

        [HttpDelete("delete/{educationID}")]
        public async Task<IActionResult> DeleteEducation(int educationID)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _educationServices.DeleteEducation(userId, educationID);
            return Ok(new { Message = result });
        }


    }
}
