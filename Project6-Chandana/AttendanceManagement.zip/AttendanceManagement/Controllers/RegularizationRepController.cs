﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Model;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AttendanceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegularizationController(IRegularizationRequestServices services) : ControllerBase
    {
        private readonly IRegularizationRequestServices _services = services;

        [HttpPost("create")]
        [Authorize(Roles = "User,Admin")]
        public async Task<IActionResult> CreateRegularizationRequest([FromBody] RegularizationCommandModel requestModel)
        {
            try
            {
                // Get user ID from claims
                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

                // Call the repository to create the regularization request
                var request = await _services.CreateRegularizationRequestAsync(userId, requestModel.AttendanceDate, requestModel.Reason);

                return Ok(new { Message = "Request created successfully.", RequestId = request.RequestId, Status = request.Status });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while creating the request.", Error = ex.Message });
            }
        }


        [HttpPut("admin/approve-or-deny/{requestId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApproveOrDenyRequest(int requestId, [FromBody] bool isApproved)
        {
            var adminId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var success = await _services.ApproveOrDenyRequestAsync(requestId, isApproved, adminId);

            if (!success) return NotFound("Request not found.");
            return Ok("Request processed successfully.");
        }

        [HttpGet("user/{userId}/requests")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetRegularizationRequestsByUser(int userId)
        {
            if (userId != int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)))
                return Unauthorized();

            var requests = await _services.GetRegularizationRequestsByUserIdAsync(userId);
            return Ok(requests);
        }

        [HttpGet("admin/requests/pending")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPendingRequests()
        {
            var pendingRequests = await _services.GetPendingRegularizationRequestsAsync();
            return Ok(pendingRequests);
        }
    }
}
