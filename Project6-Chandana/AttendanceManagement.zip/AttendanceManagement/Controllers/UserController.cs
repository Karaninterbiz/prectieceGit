﻿using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AttendanceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserControllers : ControllerBase
    {
        private readonly IUserServices _userservices;

        public UserControllers(IUserServices userServices)
        {
            _userservices = userServices;
        }
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] UserCommandModel userDTO)
        {
            if (ModelState.IsValid)
            {
                var existingUser = await _userservices.GetUserByEmailAsync(userDTO.Email);
                if (existingUser != null)
                {
                    return Conflict("A user with this email already exists.");
                }

                //if (userDTO.Role == Role.Admin)
                //{
                //    return Unauthorized("Only an existing Admin can register new Admins.");
                //}

                var createdUser = await _userservices.CreateUserAsync(userDTO);
                return Ok(createdUser);
            }

            return BadRequest(ModelState);
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDTO loginDTO)
        {
            try
            {

                var token = await _userservices.LoginAsync(loginDTO);
                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                return Unauthorized(new { Message = ex.Message });
            }
        }
        [HttpPost("change-password")]
        [Authorize] // Only authenticated users can change password
        public async Task<IActionResult> ChangePassword(PasswordChangeDTO passwordChangeDTO)
        {
            try
            {
                var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
                if (userIdClaim == null)
                    return Unauthorized("User not authenticated.");

                int userId = int.Parse(userIdClaim.Value);
                var result = await _userservices.ChangePasswordAsync(userId, passwordChangeDTO);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        [HttpPut("update-profile")]
        [Authorize] // Only authenticated users can update their profile
        public async Task<IActionResult> UpdateProfile(UserCommandModel userUpdateDTO)
        {
            try
            {
                var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
                if (userIdClaim == null)
                    return Unauthorized("User not authenticated.");

                int userId = int.Parse(userIdClaim.Value);
                var result = await _userservices.UpdateUserAsync(userId, userUpdateDTO);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        //[HttpPut("update")]
        //[Authorize]
        //public async Task<IActionResult> UpdateUser(int id, [FromBody] UserDTO userDTO)
        //{
        //    var user = await _userservices.GetUserByIdAsync(id);
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }

        //    var updatedUser = await _userservices.UpdateUserAsync(id, userDTO);
        //    return Ok(updatedUser);
        //}

        [HttpGet("profile")]
        [Authorize] // Ensure that only authenticated users can access this endpoint
        public ActionResult<UserProfileDto> GetUserProfile()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)); // Assumes userId is stored in token claims
            var userProfile = _userservices.GetUserProfile(userId);

            if (userProfile == null)
                return NotFound("User profile not found.");

            return Ok(userProfile);
        }
        [HttpDelete("api/delete")]
        [Authorize]
        public async Task<IActionResult> UserDelete()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var result = await _userservices.DeleteUserAsync(userId);
            return Ok(new { Message = result });
        }
        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            var token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            if (!string.IsNullOrEmpty(token))
            {
                await _userservices.StoreTokenAsync(token, userId);
                return Ok(new { message = "Logout successful. Token invalidated." });
            }

            return BadRequest(new { message = "Token not found." });
        }

        //[HttpDelete("{id}")]
        //[Authorize(Roles = "Admin")]
        //public async Task<IActionResult> DeleteUser(int id)
        //{
        //    var success = await _userservices.DeleteUserAsync(id);
        //    if (!success)
        //    {
        //        return NotFound();
        //    }

        //    return NoContent();
        //}
    }
}

