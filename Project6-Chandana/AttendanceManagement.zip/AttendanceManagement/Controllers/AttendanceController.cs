﻿
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

using AttendanceManagement.Model;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using AttendanceManagement.CommandModels;
using AttendanceManagement.Services.Abstractions;

namespace AttendanceManagement.Controllers
{
    [Authorize(Roles = "User,Admin")]
    [ApiController]
    [Route("api/[controller]")]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceServices _attendanceServices;

        public AttendanceController(IAttendanceServices attendanceServices)
        {
            _attendanceServices = attendanceServices;
        }

        [HttpGet("my-attendance")]
        public async Task<IActionResult> GetMyAttendance()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            if (userId == null)
            {
                return Unauthorized(new { message = "User not authenticated." });
            }


            var attendanceRecords = await _attendanceServices.GetAttendanceByUserIdAsync(userId);

            if (attendanceRecords == null || attendanceRecords.Count == 0)
            {
                return NotFound(new { message = "No attendance records found." });
            }

            return Ok(attendanceRecords);
        }

        [HttpPost("mark-attendance")]
        public async Task<IActionResult> MarkAttendance([FromBody] AttendanceRequest request)
        {

            Console.WriteLine("Start");
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            if (userId == null)
            {
                return Unauthorized(new { message = "User not authenticated." });
            }
            Console.WriteLine("End");

            var attendance = new Attendance
            {
                UserId = userId,
                AttendanceDate = DateTime.UtcNow,
                Status = request.Status.ToString(),
                Remarks = request.Remarks,
                CreatedAt = DateTime.UtcNow
            };

            await _attendanceServices.AddAsync(attendance);

            return Ok(new { message = "Attendance marked successfully." });
        }

        [HttpGet("monthly/{month}/{year}")]
        public async Task<IActionResult> GetMonthlyAttendanceReport(int month, int year)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            if (userId <= 0)
            {
                return Unauthorized(new { message = "User not authorized." });
            }

            var attendanceRecords = await _attendanceServices.GetAttendanceByUserIdAndMonthAsync(userId, month, year);

            if (attendanceRecords == null || !attendanceRecords.Any())
            {
                return NotFound(new { message = "No attendance records found for the selected month." });
            }

            var attendanceReport = attendanceRecords.Select(a => new AttendanceDTO
            {
                AttendanceId = a.AttendanceId,
                Date = a.AttendanceDate,
                Status = a.Status,
                IsPresent = a.Status == "Present"
            }).ToList();

            return Ok(attendanceReport);
        }
    }

    public class AttendanceRequest
    {
        public AttendanceStatus Status { get; set; }
        public string? Remarks { get; set; }
    }

    public enum AttendanceStatus
    {
        Present,
        Absent,
        Leave,
        Late
    }

    public class AttendanceDTO
    {
        public int AttendanceId { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
        public bool IsPresent { get; set; }
    }
}
