﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class Education
{
    public int EducationId { get; set; }

    public int UserId { get; set; }

    public string Degree { get; set; } = null!;

    public string? FieldOfStudy { get; set; }

    public string Institution { get; set; } = null!;

    public short YearOfCompletion { get; set; }

    public decimal? Gpa { get; set; }

    public string? GradeType { get; set; }

    public string? Achievements { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
