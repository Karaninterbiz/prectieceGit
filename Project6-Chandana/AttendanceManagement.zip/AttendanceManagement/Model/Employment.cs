﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class Employment
{
    public int EmploymentId { get; set; }

    public int UserId { get; set; }

    public string JobTitle { get; set; } = null!;

    public string CompanyName { get; set; } = null!;

    public string? Location { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public bool? IsCurrentJob { get; set; }

    public string? Description { get; set; }

    public string? Responsibilities { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
