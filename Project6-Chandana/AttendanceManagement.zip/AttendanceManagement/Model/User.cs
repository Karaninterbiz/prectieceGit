﻿namespace AttendanceManagement.Model;

public partial class User
{
    public int UserId { get; set; }

    public string Name { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Role { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();

    public virtual ICollection<Attendance> Attendances { get; set; } = new List<Attendance>();

    public virtual ICollection<Education> Educations { get; set; } = new List<Education>();

    public virtual ICollection<Employment> Employments { get; set; } = new List<Employment>();

    public virtual ICollection<MonthlyAttendanceReport> MonthlyAttendanceReports { get; set; } = new List<MonthlyAttendanceReport>();

    public virtual ICollection<RegularizationRequest> RegularizationRequestAdmins { get; set; } = new List<RegularizationRequest>();

    public virtual ICollection<RegularizationRequest> RegularizationRequestUsers { get; set; } = new List<RegularizationRequest>();

    public virtual ICollection<UserSession> UserSessions { get; set; } = new List<UserSession>();
}
