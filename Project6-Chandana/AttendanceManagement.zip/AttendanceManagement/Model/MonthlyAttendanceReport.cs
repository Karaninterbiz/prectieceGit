﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class MonthlyAttendanceReport
{
    public int ReportId { get; set; }

    public int UserId { get; set; }

    public DateOnly MonthYear { get; set; }

    public int TotalDays { get; set; }

    public int PresentDays { get; set; }

    public int AbsentDays { get; set; }

    public int? LeaveDays { get; set; }

    public int? LateDays { get; set; }

    public DateTime? GeneratedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
