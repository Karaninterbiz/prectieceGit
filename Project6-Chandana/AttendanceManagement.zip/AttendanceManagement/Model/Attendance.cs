﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class Attendance
{
    public int AttendanceId { get; set; }

    public int UserId { get; set; }

    public DateTime AttendanceDate { get; set; }

    public string Status { get; set; } = null!;

    public string? Remarks { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<RegularizationRequest> RegularizationRequests { get; set; } = new List<RegularizationRequest>();

    public virtual User User { get; set; } = null!;
}
