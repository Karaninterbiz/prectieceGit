﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class Project6Attendancemanagement
{
    public int? IdProject6AttendanceManagement { get; set; }
}
