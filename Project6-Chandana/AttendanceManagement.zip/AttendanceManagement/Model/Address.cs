﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class Address
{
    public int AddressId { get; set; }

    public int UserId { get; set; }

    public string? AddressType { get; set; }

    public string Street { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;

    public string? ZipCode { get; set; }

    public string? Country { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
