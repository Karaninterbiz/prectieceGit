﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class UserSession
{
    public int TokenId { get; set; }

    public int UserId { get; set; }

    public string Token { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
