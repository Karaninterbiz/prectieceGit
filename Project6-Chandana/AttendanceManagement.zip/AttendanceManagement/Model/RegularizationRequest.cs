﻿using System;
using System.Collections.Generic;

namespace AttendanceManagement.Model;

public partial class RegularizationRequest
{
    public int RequestId { get; set; }

    public int UserId { get; set; }

    public int? AdminId { get; set; }

    public int AttendanceId { get; set; }

    public string Reason { get; set; } = null!;

    public string? Status { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual User? Admin { get; set; }

    public virtual Attendance Attendance { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
